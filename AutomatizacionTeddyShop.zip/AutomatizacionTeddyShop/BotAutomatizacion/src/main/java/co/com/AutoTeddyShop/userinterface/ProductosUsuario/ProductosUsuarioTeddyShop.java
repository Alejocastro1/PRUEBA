package co.com.AutoTeddyShop.userinterface.ProductosUsuario;

import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl(value = "http://localhost:5173/productos-usuario")

public class ProductosUsuarioTeddyShop extends PageObject {
}
