package co.com.AutoTeddyShop.userinterface.ProductosAdmin;

import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl(value = "http://localhost:5173/productos")

public class ProductoAdminTeddyShop extends PageObject {
}