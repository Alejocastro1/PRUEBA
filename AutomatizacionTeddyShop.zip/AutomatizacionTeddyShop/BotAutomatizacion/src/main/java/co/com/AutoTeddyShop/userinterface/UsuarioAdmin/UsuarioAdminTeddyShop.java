package co.com.AutoTeddyShop.userinterface.UsuarioAdmin;

import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl(value = "http://localhost:5173/usuarios") // URL de gestión de usuarios
public class UsuarioAdminTeddyShop extends PageObject {
}