package co.com.AutoTeddyShop.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import static co.com.AutoTeddyShop.userinterface.UsuarioAdmin.InteraccionUsuariosAdmin.MENSAJE_CONFIRMACION;
import static net.serenitybdd.screenplay.questions.WebElementQuestion.the;

public class ValidacionUsuario implements Question<Boolean> {
    public static ValidacionUsuario mensajeExitoso() {
        return new ValidacionUsuario();
    }

    @Override
    public Boolean answeredBy(Actor actor) {
        return the(MENSAJE_CONFIRMACION).answeredBy(actor).isCurrentlyVisible();
    }
}