package co.com.AutoTeddyShop.userinterface.Empleado;

import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl(value = "http://localhost:5173/empleado")

public class EmpleadoTeddyShop extends PageObject {
}
