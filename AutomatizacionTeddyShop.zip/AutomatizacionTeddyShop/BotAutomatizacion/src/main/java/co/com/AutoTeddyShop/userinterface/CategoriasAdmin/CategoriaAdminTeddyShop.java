package co.com.AutoTeddyShop.userinterface.CategoriasAdmin;

import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl(value = "http://localhost:5173/categoria")

public class CategoriaAdminTeddyShop extends PageObject {
}