package co.com.AutoTeddyShop.userinterface.CatalogosUsuario;

import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl(value = "http://localhost:5173/Home")

public class CatalogosUsuarioTeddyShop extends PageObject {
}