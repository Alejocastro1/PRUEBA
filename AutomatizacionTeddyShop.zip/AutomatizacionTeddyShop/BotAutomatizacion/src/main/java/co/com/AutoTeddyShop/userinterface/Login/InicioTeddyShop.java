package co.com.AutoTeddyShop.userinterface.Login;

import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl(value = "http://localhost:5173/login")

public class InicioTeddyShop extends PageObject {

}
